# Proyecto-Ing-Sofware
Proyecto de Ingeniería de Software.

Sistema administrativo y financiero para una empresa guatemalteca de alquiler, venta y taller de vehículos importados de EE. UU.

| Carpeta | Contenido |
|---|---|
| [`planificacion/`](planificacion/README.md) | Descripción de la empresa, épicas, historias de usuario, User Story Mapping y [Planning](planificacion/Planning.md) |
| [`backend/`](backend/README.md) | API del Sprint 1 (corte transversal), pruebas y script de demostración |

Para levantar la API: `cd backend && docker compose up -d --build` y abrir http://localhost:8000/docs.
